import { cn } from "@/lib/utils";
import Image from "next/image";
import React from "react";

interface ImageDescriptionProps {
  className?: string;
  text: string;
  url: string;
}

const ImageDescription = ({
  className = "",
  text,
  url,
}: ImageDescriptionProps) => {
  return (
    <div className="w-full">
      <div className={cn(" ", className)}>
        <Image
          src={url}
          alt={text}
          width={5000}
          height={5000}
          quality={100}
          className=" w-full h-full object-cover shadow-lg rounded-md "
        />
      </div>

      <p className="text-center py-1">{text}</p>
    </div>
  );
};

export default ImageDescription;
