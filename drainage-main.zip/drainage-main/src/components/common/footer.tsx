import Image from "next/image";
import React from "react";
import { FaPhone, FaEnvelope } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="max-w-[1400px] mx-auto">
      {/* Background Image Section */}
      <div className="w-full ">
        <Image
          src="/Images/footer-image.jpg"
          alt="Footer Background"
          width={1400}
          height={300}
          objectFit="cover"
          className="object-cover"
        />
      </div>

      {/* Footer Content */}
      <div className="px-2 py-2 bg-[#7b9645] text-white ">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
          <p className="text-sm text-gray-200">
            © {new Date().getFullYear()} All Rights Reserved
          </p>
          
          <a href="tel:+15192270731" className="flex items-center justify-center md:justify-start gap-2 hover:text-black">
            <FaPhone /> <span className="">Phone: 519-227-0731</span>
          </a>
          
          <a href="tel:+15198788918" className="flex items-center justify-center md:justify-start gap-2 hover:text-black">
            <FaPhone className="" /> <span className="">Cell: 519-878-8918</span>
          </a>
          
          <a href="mailto:john@tdsdrainage.com" className="flex items-center justify-center md:justify-start gap-2 hover:text-black">
            <FaEnvelope /> <span className="">Email: john@tdsdrainage.com</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
