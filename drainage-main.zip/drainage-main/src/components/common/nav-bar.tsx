"use client";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ChevronDown, ChevronRight, Menu } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useMemo } from "react";

type NavLink = {
  name: string;
  url?: string;
  children?: NavLink[];
};

const navLinks: NavLink[] = [
  { name: "Home", url: "/" },

  { name: "Collector Drains", url: "/collector-drains" },
  { name: "Slit Drains", url: "/slit-drains" },
  { name: "Existing Green Drainage", url: "/existing-green-drainage" },
  {
    name: "Irrigation Pond Construction",
    url: "/irrigation-pond-construction",
  },
  {
    name: "Sport Field",
    children: [
      {
        name: "Drainage",
        children: [
          { name: "Slit Drainage", url: "/sport-drainage/slit-drains" },
          {
            name: "Collector Drainage",
            url: "/sport-drainage/collector-drains",
          },
        ],
      },
      { name: "Sandcapping", url: "/sport-sandcapping" },
      {
        name: "Renovation",
        children: [
          { name: "Soil Renovation", url: "/sport-renovation/soil-renovation" },
          { name: "Turf Renovation", url: "/sport-renovation/turf-renovation" },
        ],
      },
    ],
  },
  { name: "Articles", url: "/article" },
  { name: "Clients", url: "/client" },
  { name: "Contact", url: "/contact" },
];

const Navbar = () => {
  const memoizedNavLinks = useMemo(() => navLinks, []);

  return (
    <nav className="">
      <div className="max-w-[1400px] mx-auto px-2 lg:px-0 bg-[#7b9645] text-white ">
        <Link href="/" className="crusor-pointer">
          <Image
            src="/Images/headerImage.jpg"
            width={1400}
            height={300}
            alt="bg"
            className=" w-full h-full object-cover"
          />
        </Link>
        <div className=" flex justify-between items-center lg:flex-none ">
          {/* Logo */}
          <Link href="/" className="py-1 h-12 lg:hidden">
            <Image
              src="/Images/logo.png"
              alt="Logo"
              width={160}
              height={60}
              className=" h-10  w-auto object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden w-full lg:flex justify-between   items-center gap-4">
            {memoizedNavLinks.map((link) => (
              <div
                key={link.name}
                className="relative group hover:bg-[#7b9645]/20 rounded-lg transition-colors"
              >
                {link.url ? (
                  <Link
                    href={link.url}
                    className="px-4 py-2 flex items-center gap-1"
                  >
                    {link.name}
                  </Link>
                ) : (
                  <button className="px-4 py-2 flex items-center gap-1">
                    {link.name} <ChevronDown size={18} className="mt-0.5" />
                  </button>
                )}

                {link.children && (
                  <div className="absolute top-full left-0 hidden group-hover:block bg-white  text-[#7b9645] min-w-[240px] rounded-lg shadow-xl z-50 border border-gray-100">
                    <div className="py-2">
                      {link.children.map((child) => (
                        <div
                          key={child.name}
                          className="group/sub relative px-2 hover:bg-gray-50"
                        >
                          {child.url ? (
                            <Link
                              href={child.url}
                              className="block px-3 py-2.5 rounded-md"
                            >
                              {child.name}
                            </Link>
                          ) : (
                            <>
                              <div className="flex items-center justify-between px-3 py-2.5 rounded-md cursor-pointer">
                                {child.name}
                                <ChevronRight
                                  size={16}
                                  className="text-gray-500 ml-2"
                                />
                              </div>
                              <div className="hidden group-hover/sub:block absolute left-full top-0 bg-white min-w-[240px] rounded-lg shadow-xl border border-gray-100 ml-1 z-50">
                                <div className="py-2">
                                  {child.children?.map((grandChild) => (
                                    <Link
                                      key={grandChild.name}
                                      href={grandChild.url || "#"}
                                      className="block px-4 py-2.5 hover:bg-gray-50"
                                    >
                                      {grandChild.name}
                                    </Link>
                                  ))}
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden">
            <Sheet>
              <SheetTrigger className="p-2 hover:bg-green-800 rounded-lg transition-colors relative">
                <Menu size={24} />
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-[85vw] max-w-[320px] min-h-screen bg-green-900/40 text-white overflow-y-auto bg-[url('/Images/bgImage.jpg')] bg-cover h-full bg-center"
              >
                <SheetHeader>
                  <Link href="/" className="py-1">
                    <Image
                      src="/Images/logo.png"
                      alt="Logo"
                      width={160}
                      height={60}
                      className="h-14 w-auto object-contain"
                    />
                  </Link>
                </SheetHeader>
                <div className="flex flex-col pt-6 gap-6">
                  {memoizedNavLinks.map((link) => (
                    <Accordion key={link.name} type="single" collapsible>
                      <AccordionItem
                        key={link.name}
                        value={link.name}
                        className="border-none"
                      >
                        {link.url ? (
                          <SheetClose asChild>
                            <Link
                              href={link.url}
                              className="px-4 py-2 flex items-center gap-1 border bg-green-900/90 rounded-md"
                            >
                              {link.name}
                            </Link>
                          </SheetClose>
                        ) : (
                          <>
                            <AccordionTrigger className="px-4 py-2 flex items-center gap-1 border bg-green-900/90 rounded-md">
                              {link.name}
                            </AccordionTrigger>
                            <AccordionContent className="flex flex-col mx-4 gap-4 pt-4 w-full">
                              {link.children?.map((child) => (
                                <Accordion
                                  key={child.name}
                                  type="single"
                                  collapsible
                                  className="border-none  "
                                >
                                  <AccordionItem
                                    key={child.name}
                                    value={child.name}
                                    className="border-none w-full border-red-500 border"
                                  >
                                    {child.url ? (
                                      <div className="flex flex-col mr-4 gap-4  ">
                                        <SheetClose asChild>
                                          <Link
                                            href={child.url}
                                            className="px-4 py-2.5  block bg-green-800/80 border w-full rounded-md  "
                                          >
                                            {child.name}
                                          </Link>
                                        </SheetClose>
                                      </div>
                                    ) : (
                                      <>
                                        <AccordionTrigger className="px-4 py-2 flex items-center  mr-4 gap-4     border bg-green-900/80 rounded-md">
                                          {child.name}
                                        </AccordionTrigger>
                                        <AccordionContent className="flex flex-col mx-4 gap-4 pt-4">
                                          {child.children?.map((grandChild) => (
                                            <SheetClose
                                              key={grandChild.name}
                                              asChild
                                            >
                                              <Link
                                                href={grandChild.url || "#"}
                                                className="px-4 py-2.5 border w-full rounded-md bg-green-700/80"
                                              >
                                                {grandChild.name}
                                              </Link>
                                            </SheetClose>
                                          ))}
                                        </AccordionContent>
                                      </>
                                    )}
                                  </AccordionItem>
                                </Accordion>
                              ))}
                            </AccordionContent>
                          </>
                        )}
                      </AccordionItem>
                    </Accordion>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
