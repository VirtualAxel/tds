import React from "react";
import ImageDescription from "./image-desc";

interface ImageDescriptionProps {
  header?: string;
  data: {
    text: string;
    url: string;
  }[];
  className?: string;
}

const HeaderDescriptionSection = ({ header, data ,className}: ImageDescriptionProps) => {
  return (
    <section className="w-full   lg:text-left ">
      {header && <h2 className="text-2xl font-bold mb-4">{header}</h2>}
      <div className="grid grid-cols-1  sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 place-content-center place-items-start gap-4">
        {data.map((item) => (
          <ImageDescription
            key={item.url}
            text={item.text}
            url={item.url}
            className={className}
          />
        ))}
      </div>
    </section>
  );
};

export default HeaderDescriptionSection;
