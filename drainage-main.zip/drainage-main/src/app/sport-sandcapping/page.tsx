
const Page = () => {
  // const ImagesData = [
  //   {
  //     text: "Excess sand being applied and removed after installation is complete.",
  //     url: "/Images/slit-drains/excess-sand.jpg",
  //   },
  //   {
  //     text: "A compactor being pulled behind the trencher.",
  //     url: "/Images/slit-drains/compactor-being.jpg",
  //   },
  //   {
  //     text: "Laser grade control; slit installation.",
  //     url: "/Images/slit-drains/laser-grade.jpg",
  //   },
  //   {
  //     text: "Slit drainage installation crew.",
  //     url: "/Images/slit-drains/slit-drainaage-install.jpg",
  //   },
  //   {
  //     text: "A completed fairway Slit Drainage project.",
  //     url: "/Images/slit-drains/completed-fairway.jpg",
  //   },
  //   {
  //     text: "The TDS crew in full swing.",
  //     url: "/Images/slit-drains/the-tds-crew.jpg",
  //   },
  //   {
  //     text: "A completed fairway Slit Drainage project.",
  //     url: "/Images/slit-drains/fairway-slit-drainage-project.jpg",
  //   },
  //   {
  //     text: "A few days after the Slit Drainage system was installed. The new tee deck was built with some of the excavated soil.",
  //     url: "/Images/slit-drains/a-few-days-after-the-slit-drainage.jpg",
  //   },
  // ];
  return (
    <div className= " flex flex-col text-black gap-6 ">
      <section>
        <h1 className="text-3xl font-bold mb-6 text-left">
          Sand Capped Sports Field
        </h1>
        <p>
          A natural cost-effective solution for failing soil sports fields with
          minimal disturbance to the field. This is an environmentally
          sustainable approach versus artificial turf.
        </p>
        <div className="mt-5">
          <h2 className="text-2xl font-semibold   mb-4">
            Benefits of the TDS Sand Capped Sports Field
          </h2>
          <ul className="list-disc list-inside space-y-2 text-black">
            <li>Increase overall playability</li>
            <li>Reduce rain delays and closures</li>
            <li>Excellent &quot;wear and tear&quot; tolerance</li>
          </ul>
        </div>
      </section>
      {/* Schematic Section */}
      {/* <section className="w-full text-left">
        <h2 className="text-xl font-semibold mb-4">
          1. Installing a new drainage system
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-4">
          {ImagesData.map((item) => (
            <ImageDescription key={item.url} text={item.text} url={item.url} />
          ))}
        </div>
      </section> */}
    </div>
  );
};

export default Page;
