import HeaderDescriptionSection from "@/components/common/header-description";

const page = () => {
  const ImageData = [
    {
      text: "Slit draining at Hume Park, Westminster, B.C.",
      url: "/Images/sport/slit-drains/humepark.jpg",
    },
    {
      text: "Slit draining at Connaught Rugby Field, Vancouver, B.C.",
      url: "/Images/sport/slit-drains/connaught.jpg",
    },
    {
      text: "Slit drainage at Mt. Brenton Golf Course, Chemainus, B.C.",
      url: "/Images/sport/slit-drains/golf.jpg",
    },
    {
      text: "Slit draining the International Equestrian Arena at Spruce Meadows, Calgary, Alberta.",
      url: "/Images/sport/slit-drains/alberta.jpg",
    },
  ];
  return (
    <div className="flex flex-col text-black gap-6">
      {/* Title Section */}
      <section className="w-full   lg:text-left">
        <h1 className="text-3xl font-bold mb-4">Sports Fields Slit Drainage</h1>
        <p className="leading-relaxed">
          A slit drainage system is a network of trenches using small diameter
          perforated pipes and sand to drain away excess water from surface and
          sub-surface. Projects are surveyed, carefully designed and installed
          using an automatic, laser-controlled slit trencher.
        </p>
      </section>

      <HeaderDescriptionSection data={ImageData} />
    </div>
  );
};

export default page;
