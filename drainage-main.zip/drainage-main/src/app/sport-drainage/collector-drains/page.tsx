import ImageDescription from "@/components/common/image-desc";
import React from "react";

const Page = () => {
  return (
    <div className="  flex flex-col text-black gap-4  ">
      <h2 className="text-2xl font-semibold     sm:text-left">
        Sports Fields Collector Drainage
      </h2>

      <section className="grid grid-cols-1 sm:grid-cols-1  md:grid-cols-2 gap-6">
        <ImageDescription
          text="Laser-controlled trencher alongside running track, installing collector for slit drain system."
          url="/Images/sport/collector-drains/laser.jpg"
          className="w-full h-80 sm:h-96"
        />

        <ImageDescription
          text="Trenching collector for slit drain installation."
          url="/Images/sport/collector-drains/trenching.jpg"
          className="w-full h-80 sm:h-96"
        />
      </section>
    </div>
  );
};

export default Page;
