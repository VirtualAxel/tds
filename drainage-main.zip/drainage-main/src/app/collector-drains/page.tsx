import HeaderDescriptionSection from "@/components/common/header-description";
import ImageDescription from "@/components/common/image-desc";
import React from "react";

const Page = () => {
  const CatchBasin = [
    {
      text: "TDS crew member makes sure that the Catch Basin is level.",
      url: "/Images/collector-drains/tds-crew.jpg",
    },
    {
      text: "Drainage system connected to Catch Basin.",
      url: "/Images/collector-drains/drainage-sys.jpg",
    },
    {
      text: "Catch basin excavation backfilled with soil and sand.",
      url: "/Images/collector-drains/catch-basin.jpg",
    },
    {
      text: "TDS crew carefully replaces sod around installed Catch Basin.",
      url: "/Images/collector-drains/tds-catch.jpg",
    },
  ];
  return (
    <div className="flex flex-col gap-6">
      {/* Title Section */}
      <section className="w-full  sm:text-left">
        <h1 className="text-3xl font-bold mb-4">A Collector Drains</h1>
        <p className="leading-relaxed">
          Collector Drains are installed with an automatic laser-controlled
          trencher. The sod can be lifted and backfilled with native soil, sand,
          or pea stone. It is then compacted, excess soil removed, and sod
          relaid.
        </p>
      </section>

      {/* Content Section */}
      <section className="flex flex-col lg:flex-row gap-4 lg:gap-6 justify-center items-start">
        {/* Left Image */}
        <div className="w-full lg:w-1/4">
          <ImageDescription
            text=" Mastenbroek 10/12D with automatic laser control."
            url="/Images/collector-drains/mastenbroek.jpg"
            className=" h-52  "
          />
        </div>

        {/* Text Content */}
        <div className="w-full lg:w-2/4   sm:text-left">
          <h2 className="text-xl font-semibold mb-2">Specialized Equipment</h2>
          <p>
            Since 1992, TDS has been at the forefront of turf drainage
            solutions, delivering high-quality systems tailored to various
            landscapes across North America. With decades of expertise, we have
            successfully completed numerous projects, leveraging
            state-of-the-art equipment and innovative techniques. No matter the
            complexity of your drainage needs, TDS has the skills, technology,
            and commitment to provide efficient and long-lasting solutions.
          </p>
        </div>

        {/* Right Image */}
        <div className="w-full lg:w-1/4">
          <ImageDescription
            text=" Mastenbroek 10/12D with automatic laser control."
            url="/Images/collector-drains/cleaning.jpg"
            className=" h-52  "
          />
        </div>
      </section>

      <div className="border w-full my-6" />

      {/* Two Images in a Row */}
      <section className="w-full flex flex-col sm:flex-row justify-between items-center gap-4 lg:gap-6">
        <div className="w-full sm:w-1/2">
          <ImageDescription
            text=" Mastenbroek 10/12D with automatic laser control."
            url="/Images/collector-drains/weston-golf.jpg"
            className=""
          />
        </div>
        <div className="w-full sm:w-1/2">
          <ImageDescription
            text=" Mastenbroek 10/12D with automatic laser control."
            url="/Images/collector-drains/niakwagolf.jpg"
            className=""
          />
        </div>
      </section>

      <div className="border w-full my-6" />

      <HeaderDescriptionSection
        header="Installation of a Catch Basin"
        data={CatchBasin}
      />

      <div className="border w-full my-6" />

      {/* Two Sections with Text and Images */}
      <section className="w-full flex flex-col sm:flex-row justify-between items-start gap-4 lg:gap-6">
        <div className="w-full sm:w-1/2  lg:text-left ">
          <h2 className="text-xl font-semibold mb-4">Fairway Drainage</h2>
          <ImageDescription
            text="TDS crew installing collector drainage system on a fairway at Hamilton Golf and Country Club, Ancaster, Ontario."
            url="/Images/collector-drains/fairway.jpg"
            className=" h-96"
          />
        </div>
        <div className="w-full sm:w-1/2  lg:text-left  ">
          <h2 className="text-xl font-semibold mb-4">Cemetery Drainage</h2>
          <ImageDescription
            text="TDS crew installing a drainage system in a cemetery for the town of Oakville, Ontario."
            url="/Images/collector-drains/cemetery.jpg"
            className=" h-96"
          />
        </div>
      </section>
    </div>
  );
};

export default Page;
