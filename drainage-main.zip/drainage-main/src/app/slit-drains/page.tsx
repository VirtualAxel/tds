import HeaderDescriptionSection from "@/components/common/header-description";
import Image from "next/image";

const Page = () => {
  const ImagesData = [
    {
      text: "Excess sand being applied and removed after installation is complete.",
      url: "/Images/slit-drains/excess-sand.jpg",
    },
    {
      text: "A compactor being pulled behind the trencher.",
      url: "/Images/slit-drains/compactor-being.jpg",
    },
    {
      text: "Laser grade control; slit installation.",
      url: "/Images/slit-drains/laser-grade.jpg",
    },
    {
      text: "Slit drainage installation crew.",
      url: "/Images/slit-drains/slit-drainaage-install.jpg",
    },
    {
      text: "A completed fairway Slit Drainage project.",
      url: "/Images/slit-drains/completed-fairway.jpg",
    },
    {
      text: "The TDS crew in full swing.",
      url: "/Images/slit-drains/the-tds-crew.jpg",
    },
    {
      text: "A completed fairway Slit Drainage project.",
      url: "/Images/slit-drains/fairway-slit-drainage-project.jpg",
    },
    {
      text: "A few days after the Slit Drainage system was installed. The new tee deck was built with some of the excavated soil.",
      url: "/Images/slit-drains/a-few-days-after-the-slit-drainage.jpg",
    },
  ];
  return (
    <div className="  flex flex-col   gap-6 ">
      <section>
        <h1 className="text-3xl font-bold mb-6 text-left">Slit Drains</h1>

        <div className="flex flex-col lg:flex-row justify-between items-start gap-6 lg:gap-12">
          {/* Image */}
          <div className="w-full lg:w-1/2">
            <Image
              src="/Images/slit-drains/sllit-drainage.jpg"
              alt="TDS Project"
              width={500}
              height={500}
              quality={100}
              className="w-full h-80 shadow-lg rounded-lg"
            />
          </div>

          {/* Text Content */}
          <div className="w-full lg:w-1/2 text-justify sm:text-left">
            <p>
              This system is a network of trenches, using small diameter
              perforated pipes and sand to drain away excess water from surface
              and sub-surface. Projects are surveyed, carefully designed, and
              installed using an automatic laser-controlled slit trencher.
              <br />
              <br />
              When installing a Slit Drainage System, we &quot;buzz&quot; out a
              trench 12&quot; to 24&quot; deep. The machine is laser controlled
              for accurate grading, the spoils are loaded and hauled away, and a
              1½&quot; or 2&quot; drainage pipe is laid in behind. The trench is
              then backfilled with coarse sand, leaving only a 3&quot; wide
              sand-filled channel visible. This system is clean, fast, and the
              results are amazing.
            </p>
          </div>
        </div>
      </section>

      <HeaderDescriptionSection
        header="Representative As-Built Schematic for a Fairway Slit Drainage Project"
        data={ImagesData}
      />
    </div>
  );
};

export default Page;
