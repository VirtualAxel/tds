import HeaderDescriptionSection from "@/components/common/header-description";

const page = () => {
  const ImageData = [
    {
      text: "",
      url: "/Images/sport/soil/first.jpg",
    },
    {
      text: "",
      url: "/Images/sport/soil/second.jpg",
    },
    {
      text: "",
      url: "/Images/sport/soil/third.jpg",
    },
  ];
  return (
    <div className="  mx-auto flex flex-col   gap-6 ">
      {/* Title Section */}
      <section className="w-full   lg:text-left">
        <h1 className="text-3xl font-bold mb-4">Soil Renovating</h1>
        <p className="leading-relaxed">
          This equipment will till the soil, break up clods, and bury stones and
          debris. It prepares a seed bed and blends materials such as compost,
          sand or top soil.
        </p>
      </section>

      <HeaderDescriptionSection data={ImageData} />
    </div>
  );
};

export default page;
