import HeaderDescriptionSection from "@/components/common/header-description";

const page = () => {
  const ImageData = [
    {
      text: "",
      url: "/Images/sport/turf/first.jpg",
    },
    {
      text: "",
      url: "/Images/sport/turf/second.jpg",
    },
    {
      text: "",
      url: "/Images/sport/turf/third.jpg",
    },
  ];
  return (
    <div className="  flex flex-col   gap-6 ">
      <section className="w-full   lg:text-left">
        <h1 className="text-3xl font-bold mb-4">Turf Renovating</h1>
        <p className="leading-relaxed">
          A total sod removal system that accurately levels playing surfaces.
          Equipped as a fraise mower, it removes weeds and promotes new turf
          growth. It is fitted with detaching blades that removes thatch while
          conveying into a dumper for disposal.
        </p>
      </section>

      <HeaderDescriptionSection data={ImageData} />
    </div>
  );
};

export default page;
