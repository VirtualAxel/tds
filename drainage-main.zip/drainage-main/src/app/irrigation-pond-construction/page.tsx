import HeaderDescriptionSection from "@/components/common/header-description";

const page = () => {
  const ImageData = [
    {
      text: "Excavation of the irrigation pond site begins.",
      url: "/Images/irrigation-pond-construction/excavation.jpg",
    },
    {
      text: "The irrigation pond site excavation progresses.",
      url: "/Images/irrigation-pond-construction/irrigation.jpg",
    },
    {
      text: "TDS crews unroll and fit Bentonite liner panels to irrigation pond walls.",
      url: "/Images/irrigation-pond-construction/crew-unroll.jpg",
    },
    {
      text: "Bentonite liner is fitted to irrigation pond site.",
      url: "/Images/irrigation-pond-construction/bentonite.jpg",
    },
  ];
  return (
    <div className="  flex flex-col  gap-6 ">
      {/* Title Section */}
      <section className="w-full   lg:text-left">
        <h1 className="text-3xl font-bold mb-4">
          Irrigation Pond Construction
        </h1>
        <p className="leading-relaxed">
          Bentonite liners are often used to construct and seal irrigation ponds
          due to their efficiency. TDS will build a custom pond on your site to
          meet your specific needs.
        </p>
      </section>

      <HeaderDescriptionSection header="" data={ImageData} className="h-52" />
    </div>
  );
};

export default page;
