import Image from "next/image";
import React from "react";

const Page = () => {
  return (
    <div className=" ">
      <div className=" ">
        <h1 className="text-4xl font-bold mb-4 text-center" style={{ color: "#7B9645" }}>
          Down the Tubes: <br />
          <em className=" text-3xl" style={{ color: "#7B9645" }}>
            The Benefits of Subsurface Drainage
          </em> 
        </h1>
        <p className="  font-semibold text-center text-black">
          By John Van Roestel, Owner of TDS Turf Drainage Systems Ltd.
        </p>

        <p className="text-xl leading-relaxed my-4">
          How and why a subsurface drainage system works is sometimes difficult
          to explain and often hard to justify — until you see the results. A
          properly installed and maintained drainage system can effectively deal
          with both surface and subsurface drainage water. At the same time, it
          can save money by improving turf health and reducing maintenance
          costs, and can actually pay dividends by eliminating or reducing golf
          course closures due to rain.
        </p>

        <div className="flex flex-col-reverse lg:flex-row justify-between gap-6">
          <div className="w-full lg:w-3/5">
            <h2
              className="text-2xl font-semibold my-4"
              style={{ color: "#7B9645" }}
            >
              Drainage 101
            </h2>
            <p className="leading-relaxed">
              When soil is properly drained, a thin layer of capillary water is
              held onto soil particles, and air fills the remaining space. This
              combination of soil, air and water is the ideal environment for
              roots and beneficial organisms. Drains provide an escape route for
              excess water in soil. Healthier roots will survive any subsequent
              drought better, and many moisture-related diseases like Pythium
              root rot, Pythium blight, Rhizoctonia brown patch and other
              diseases will be avoided.
            </p>

            <h2
              className="text-2xl font-semibold my-4 "
              style={{ color: "#7B9645" }}
            >
              Other advantages to good drainage include:
            </h2>
            <ul className="list-disc pl-6 space-y-2 ">
              <li>
                <strong>Greater soil load-bearing ability.</strong> Foot traffic
                from golfers as well as wheeled traffic from golf carts and
                mowing equipment will cause less compaction to well-drained
                soil. A good drainage system will promote better turf growth,
                and speed up play.
              </li>
              <li>
                <strong>Better water absorption</strong> after a rainfall, as
                well-drained soil has more air space. This reduces surface
                runoff and ponding in low-lying areas. In poorly drained soil,
                these spaces are waterlogged, and pooling and flooding are often
                the result.
              </li>
              <li>
                <strong>Improvement of subsoil moisture conditions.</strong> A
                subsurface drainage system lowers the water table for a
                considerable distance from the drain.
              </li>
            </ul>
          </div>

          <div className="w-full lg:w-2/5 flex justify-center   ">
            <Image
              src="/Images/article/golf.jpg"
              width={500}
              height={488}
              quality={100}
              className="rounded-lg shadow-lg w-full h-full  object-cover lg:h-[500px] "
              alt="Golf Course"
            />
          </div>
        </div>

        <h2
          className="text-2xl font-semibold my-4 "
          style={{ color: "#7B9645" }}
        >
          Before you start
        </h2>
        <p className="leading-relaxed">
          When designing a drainage system, it is important to know the area in
          terms of the course’s watershed. A topographical survey will be needed
          to determine this. The resulting topographical map can cover hundreds
          or even thousands of acres depending on the golf course. (Figure 1 is
          a topographical map of just one green.) With this information,
          calculations can then be made on how much water will have to be dealt
          with.
          <br />A consideration often overlooked when designing a drainage
          system is pipe size. A 100-mm (4-in.) pipe may be sufficient for a
          drainage system on your fairway this year, but what about next year or
          the year after that? You may want to drain other fairways or drain a
          sand trap into the same pipe, which will then become suddenly
          undersized.
        </p>

        <h2
          className="text-2xl font-semibold my-4 "
          style={{ color: "#7B9645" }}
        >
          Collector drains
        </h2>
        <p className="leading-relaxed">
          Collector drains are the foundation of any drainage system. They are
          usually the longest and the deepest drains on a golf course, 150 mm (6
          in.) in diameter and .9 m (3 ft) deep. These main lines carry the
          drainage water collected by lateral drains to an outlet, which could
          be a pond, river or stream. They are normally installed in the
          lowest-lying part of the area to be drained and are sized according to
          how much water will be going into them and the percentage of slope on
          the drain. A drain with a one per cent slope will move more water then
          a drain with a .1 per cent slope.
          <br />
          The amount of water flowing into a collector depends on many
          variables. Some of the more obvious ones are the total area of land
          drained into the system and the type of drainage system—for instance,
          whether it is a slit drain system with sand backfill or one with
          native-soil backfill. Other variables include the amount of surface
          inlets and catch basins.
          <br />
          By themselves, collectors can have a huge impact on an area. When
          installed with properly designed and situated catch basins, excess
          rainwater can be handled with ease. While collectors can often get rid
          of the bulk of the water on their own, more often than not, they are
          usually the first phase of a two-phase drainage system project.
          <br />
          There are two main types of drainage systems, and either or both can
          be used on the same course:
        </p>
        <h2
          className="text-2xl font-semibold my-4 "
          style={{ color: "#7B9645" }}
        >
          Lateral drainage systems
        </h2>
        <p className="leading-relaxed">
          The lateral drainage method involves digging a trench .6 m (2 ft) deep
          and placing a perforated 100-mm (4 in.) diameter pipe in it, which is
          then backfilled with native soil. Results will vary with this system
          depending on the type of soil. Sandy soils, for example, will drain
          faster than clay soils. The conventional method of well-placed surface
          inlets is usually effective in sandy soil because excess water moves
          very well through the soil particles.
          <br />
          While this conventional system is often adequate, with the demands on
          golf courses today, superintendents need to get players out on the
          green right after a rain—and fast! A slit-drainage system allows for
          this.
        </p>

        <div className="flex flex-col md:flex-row gap-6 my-6  ">
          <div className="w-full lg:w-1/3">
            <Image
              src="/Images/article/Slitdrainage.jpg"
              width={5000}
              height={170}
              className="rounded-lg shadow-lg  lg:h-full  xl:h-60"
              alt="Slit Drainage "
            />
          </div>
          <p className=" w-full lg:w-2/3">
            With this technique, a special wheel trencher digs a .3-m (1-ft)
            trench and conveys the native soil into a trailer running alongside.
            Simultaneously, the machine places a 50-mm (2-in.) diameter pipe
            into the trench through a chute attached to the wheel. In a second
            step, the trench is backfilled to the surface with sand or small
            stones. Often, both steps are combined into one smooth operation.
            The trencher is equipped with a state-of-the-art laser-control
            system that automatically tracks and makes corrections to keep the
            drain lines at the designed slope and depth, an important factor
            where the undulating terrain of a golf course is concerned. A sand
            or sand/stone mixture is used for fast removal of surface water. It
            is important to let the turf establish itself in the narrow sand
            trench rather than lay sod over the trench line. By establishing the
            turf in the sand, drainage performance is not affected as the water
            will move through the sand much faster then it would through layered
            sod. A filter-wrapped pipe is recommended when using sand, to avoid
            clogging, but not recommended with stone backfill.
          </p>
        </div>

        <p>
          When designing a slit drainage system, it is important to design the
          drains so they run across the ground perpendicular to the direction
          the excess water would run, and with a positive slope (.5 per cent is
          often used as a minimum). The importance of a good topographical
          survey cannot be emphasized enough at this point. The slit trenches
          are installed at an average spacing of 1.5 m (5 ft) and serve to
          collect the excess water as it runs across the ground surface,
          channeling the water to the collectors and then to an outlet.
        </p>

        <h2
          className="text-2xl font-semibold my-4"
          style={{ color: "#7B9645" }}
        >
          Problems and Solutions
        </h2>
        <p className="leading-relaxed">
          Side hill seepage is a drainage problem that most golf courses seem to
          have but can be remedied with a well-placed drain. Quite often the
          water is running along the top of a harder layer of soil or rock and
          will seep out when it reaches a more permeable area, usually the side
          of a hill or another soil type. The location and depth of the drain is
          critical to intercept the water causing the drainage problems.
          <br />
          Proper installation techniques and equipment will avoid silting in
          backgrades, and careful backfilling techniques will reduce damage from
          rocks. A good outlet is important: Well constructed, it will serve the
          drainage system for years. Animal guards are recommended to prevent
          muskrats and other animals from entering the system and causing a
          blockage. They have a hinged grate on the end of the outlet to allow
          any debris in the system to escape.
          <br />
          The installation of slit drainage systems on older greens is fast
          becoming a viable option for groundskeepers, and can save a green from
          having to be totally rebuilt. The main candidates for this system are
          old push-up-style greens, which were built with little or no
          subsurface drainage and consist of heavier surrounding native topsoil.
          Through the years, they have become compacted and have developed
          impervious layers, causing excess water to remain on the surface and
          saturate the top of the root zone. With a good drainage system, excess
          water is allowed to escape before it can freeze and cause damage to
          the surface. With the water removed, sunlight can warm the green
          faster, giving it a jump start for the new season.
          <br />
          Other problems an older green may have are high areas that drain very
          well and low areas that do not drain well at all. When the high areas
          require watering, the low areas get over-watered. Superintendents
          usually resort to hand watering in these situations. A slit drainage
          system lets the superintendent apply the right amount of water to the
          high areas, while getting rid of the excess water in the poorly
          draining ones.
        </p>

        <h2
          className="text-2xl font-semibold my-4 "
          style={{ color: "#7B9645" }}
        >
          Payback Time
        </h2>
        <p>
          It is easy to figure out the cost of a drainage system in terms of
          material and labour, but it is sometimes harder to calculate the
          payback. Here are some tangible considerations to help justify such a
          project:
        </p>
        <ul className="list-disc pl-6 space-y-2  ">
          <li>
            One or two wet spots, a waterlogged green or a fairway that stays
            wet after heavy rains can slow play or even call for course shutdown
            for a day or more. An extra day or two of green fees plus cart
            rentals can more than pay for the cost of a drainage project.
          </li>
          <li>
            A well-drained golf course can open earlier in the spring and can
            stay open later in the fall. Also, in the spring, much of the sun’s
            warmth is used to evaporate excess water from undrained soil, and
            this causes cooling. Well-drained soil is warmer in spring and thus
            provides for better growing conditions.
          </li>
          <li>
            Major reconstruction of older greens can be avoided by a properly
            designed slit-trench system.{" "}
          </li>
        </ul>

        <p className="mt-6 text-xl text-black font-semibold ">
          Properly installed, a drain will work 24 hours a day, seven days a
          week, and is virtually maintenance free. A drainage system is truly an
          investment that will repay you many times over.
        </p>
      </div>
    </div>
  );
};

export default Page;
