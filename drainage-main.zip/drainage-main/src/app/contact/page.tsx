import Script from "next/script";

const Page = () => {
  return (
    <div className="text-black p-6 rounded-lg mx-auto max-w-4xl ">
      {/* Flex container to align contact details and form in a single row */}
      <div className="flex flex-col md:flex-row items-start justify-center gap-12 ">
        {/* Contact Details */}
        <div className="text-center md:text-left w-full md:w-1/2">
          <h1 className="text-3xl font-bold mb-4 text-start">Contact Us</h1>
          <h2 className="text-xl font-semibold">Turf Drainage Systems Ltd.</h2>
          <p className="mt-2">
            13227 Elginfield Rd., Highway #7, PO Box 99
            <br /> 
            Lucan, Ontario, Canada N0M 2J0
          </p>
          <p className="mt-2">
            <strong>Phone:</strong>{" "}
            <a href="tel:+15192270731" className="text-black hover:underline">
              519-227-0731
            </a>
          </p>
          <p>
            <strong>Mobile:</strong>{" "}
            <a href="tel:+15198788918" className="text-black hover:underline">
              519-878-8918
            </a>
          </p>
          <p className="mt-2">
            <strong>Email:</strong>{" "}
            <a
              href="mailto:john@tdsdrainage.com"
              className="text-black hover:underline"
            >
              john@tdsdrainage.com
            </a>
          </p>
        </div>

        {/* Cognito Forms */}
        <div className="w-full md:w-1/2 flex justify-center">
          <iframe
            src="https://www.cognitoforms.com/f/X6pHZGegCEKFNUs_ICrhew/1"
            allow="payment"
            className="border-0 w-full max-w-md"
            height="580"
          ></iframe>
          <Script src="https://www.cognitoforms.com/f/iframe.js"></Script>
        </div>
      </div>
    </div>
  );
};

export default Page;
