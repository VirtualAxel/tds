import Footer from "@/components/common/footer";
import Navbar from "@/components/common/nav-bar";
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    template: "%s | Turf Drainage Systems Ltd",
    default: "Turf Drainage Systems Ltd",
  },
  description: "Turf Drainage Systems Ltd",

  referrer: "origin-when-cross-origin",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased   relative`}
        
      >
        <div className="absolute inset-0  bg-[url('/Images/bgImage.jpg')]   top-0 bg-repeat-x  -z-10" ></div>

        <Navbar />
        <div className=" ">
          <div className="max-w-[1400px] mx-auto text-black  bg-white  px-3 sm:px-5 lg:px-6 pt-3">{children}</div>
        </div>
        <div className="">
          <Footer />
        </div>
      </body>
    </html>
  );
}
