import Image from "next/image";

const Page = () => {
  const ontarioData = [
    "Bayview Golf & CC, Thornhill",
    "Beachgrove Golf Club, Windsor",
    "Beverly Golf Club, Copetown",
    "Brampton Golf Course, Brampton",
    "Briars Golf Club, Jacksons Point",
    "Brockville Golf & CC, Brockville",
    "Burford Golf Club, Burford",
    "Burlington Golf & CC, Burlington",
    "Cardinal Golf Club, Kettleby",
    "Castlemore Golf Club, Brampton",
    "Cataraqui Golf & CC, Kingston",
    "City of Burlington",
    "City of Oshawa",
    "City of Sarnia",
    "Craigowan Golf & CC, Woodstock",
    "Credit Valley Golf & CC, Mississauga",
    "Cutten Club, Guelph",
    "Devil's Pulpit Golf Course, Caledon",
    "Dominion Golf & CC, Windsor",
    "Don Valley Golf Course, Toronto",
    "Dundas Valley Golf & Curling Club, Dundas",
    "Essex Golf Club, Windsor",
    "Forest City National, London",
    "Fox Glen Golf Course, Windsor",
    "Granite Ridge Golf Club, Milton",
    "Greenhills Golf Club, Lambeth",
    "Grey Silo Golf Course, Waterloo",
    "Guelph Turf Grass Institute, Guelph",
    "Halton District School Board",
    "Hamilton Golf Club, Hamilton",
    "Hidden Lake Golf Club, Burlington",
    "Highland Golf Club, London",
    "Hornby Glen Golf & CC, Hornby",
    "Huron Oaks Golf Club, Sarnia",
    "Idylwylde Golf & CC, Sudbury",
    "Ironwood Golf Club, Exeter",
    "Islington Golf & CC, Islington",
    "Kawartha Golf & CC, Peterborough",
    "Kingsville Golf & CC, Kingsville",
    "Lakeview Golf Club, Mississauga",
    "Listowel Golf Club, Listowel",
    "Lively Golf & CC, Lively",
    "London District Catholic School Board",
    "London Hunt Club, London",
    "Lowville Golf Club, Lowville",
    "Magna Golf Club, Aurora",
    "Mapledowns Golf Club, Mississauga",
    "Markland Wood Country Club, Etobicoke",
    "Metro Toronto Parks and Culture",
    "Metro Toronto Zoo, Toronto",
    "Mississauga Golf & CC, Mississauga",
    "Mitchell Golf Club, Mitchell",
    "Municipality of North Middlesex, Parkhill",
    "North Halton Golf Club, Georgetown",
    "North Humber Golf Club, Toronto",
    "North Ridge Golf Course, Brantford",
    "Oakdale Golf & CC, Toronto",
    "Oakville Golf Club, Oakville",
    "Oakwood Inn, Grand Bend",
    "Owen Sound Golf Course",
    "Puslinch Lake Golf Course, Puslinch",
    "Red Tail Golf Club, St. Thomas",
    "River Road Golf Course, London",
    "Rosedale Golf Course, Toronto",
    "Roseland Golf Course, Windsor",
    "Royal Ottawa, Ottawa",
    "Saugeen Golf Club, Port Elgin",
    "Scarlett Woods Golf Course, Toronto",
    "Scenic Woods Golf Course, Hannon",
    "Sleepy Hollow, Stouffville",
    "Southern Pines Golf Course, Mt. Hope",
    "St. Catherines Golf Club, St.Catherine",
    "St. Clair Parkway Commission",
    "St. Lawrence Parks Commission, Morrisburg",
    "St. Thomas Golf Club, Union",
    "Stratford Golf & CC, Stratford",
    "Stratford Parks, Stratford",
    "Sunningdale Golf & CC, London",
    "Sunset Golf Course, Goderich",
    "Thames Valley Golf Course, London",
    "Thames Valley District School Board, London",
    "Toronto Golf Club, Toronto",
    "Town of Aurora",
    "Town of Oshawa",
    "Township of Lucan-Biddulph, Lucan",
    "Trafalgar Golf Club, Lambeth",
    "Upper Canada Golf Club, Morrisburg",
    "Western Trent Golf Course, Bolsover",
    "Westhaven Golf Club, London",
    "Westminister Trails, London",
    "Westmount Golf Course, Kitchener",
    "Weston Golf & CC, Toronto",
    "Woodland Hills Golf Club, Belle River",
    "York Downs Golf & CC, Unionville",
  ];

  const provincedata = [
    "Ashburn Golf Club, Halifax, N.S.",
    "Beloile Golf Club, Beloile, Q.C.",
    "Brudenell River Golf Course, Georgetown, P.E.",
    "Burnaby Mountain Golf Course, Burnaby, B.C.",
    "Capilano Golf & CC, N. Vancouver, B.C.",
    "City of Chiliwack, B.C.",
    "Cowichan Golf & CC, Duncan, B.C.",
    "Digby Pines Golf Resort, Digny, N.S.",
    "Glen Eagle Golf Club, N. Vancouver, B.C.",
    "Ilsemere Golf Club, Ilsemere, Q.C.",
    "Kanawake Golf Club, Kahnawake, Q.C.",
    "Kings Links Golf & CC, Richmond, B.C.",
    "Le Portage Golf & CC, Cheticamp, N.S.",
    "Mission Golf Club, Mission, B.C.",
    "Mount Brenton Golf & CC, Chemainus, B.C.",
    "Niakwa Golf & CC, Winnipeg, M.B.",
    "Northview Golf & Country Club, Surrey, B.C.",
    "Quilchena Golf & CC, Richmond, B.C.",
    "Riverway Golf Club, Burnaby, B.C.",
    "Royal Montreal Golf Club, Montreal, Q.C.",
    "Seymour Golf & Country Club, Vancouver, B.C.",
    "Spruce Meadows, Calgary, A.B.",
    "Tryall Golf Club, Montego Bay, Jamaica",
    "Vancouver Golf & CC, Vancouver, B.C.",
    "Westwood Plateau Golf & CC, Coquitlam, B.C."
]
  return (
    <div className=" flex flex-col  gap-8">
      <div className="relative">
        <Image
          src="/Images/client/client-banner.jpg"
          width="999"
          height="282"
          alt="Client Banner"
          className="w-full h-auto rounded-lg shadow-lg  "
        />
        <h1 className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-4xl font-extrabold text-white bg-black bg-opacity-50 px-6 py-2 rounded">
          Client List
        </h1>
      </div>

      <section>
        <h2 className="text-3xl font-bold border-b-2 border-gray-500 pb-2">
          Ontario
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4 text-lg leading-relaxed">
          {ontarioData.map((item, index) => (
            <p key={index} className="bg-[#7b9645] p-4 rounded-lg shadow-md">
              {item}
            </p>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold border-b-2 border-gray-500 pb-2 mt-8">
          Out of Province
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4 text-lg leading-relaxed">
          {provincedata.map((item, index) => (
            <p key={index} className="bg-[#7b9645] p-4 rounded-lg shadow-md">
              {item}
            </p>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Page;
