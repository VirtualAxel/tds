import HeaderDescriptionSection from "@/components/common/header-description";
import ImageDescription from "@/components/common/image-desc";
import React from "react";

const page = () => {
  const ImageData = [
    {
      text: "Sod is carefully sectioned and rolled before excavation begins.",
      url: "/Images/existing-green-drainage/sod.jpg",
    },
    {
      text: "Precise surveys of the grounds are taken to determine the optimum drainage plan.",
      url: "/Images/existing-green-drainage/precise.jpg",
    },
    {
      text: "TDS crew prepares greens for the installation of perforated pipes.",
      url: "/Images/existing-green-drainage/tds-prepare.jpg",
    },

    {
      text: "Sod is carefully cut and stacked in readiness for repositioning after work is complete.",
      url: "/Images/existing-green-drainage/sod-cut.jpg",
    },
    {
      text: "This catch basin was installed on the top end of the system to prevent surface water from flooding the green.",
      url: "/Images/existing-green-drainage/catch.jpg",
    },
    {
      text: "This green is complete and will be ready for play after a bit of water washes the dirt away.",
      url: "/Images/existing-green-drainage/complete-green.jpg",
    },
    {
      text: "This green was only out of play for a day and a half while work was in progress. The photo was taken 30 minutes after completion.",
      url: "/Images/existing-green-drainage/out-green.jpg",
    },

    {
      text: "The collector drain is installed first.",
      url: "/Images/existing-green-drainage/collector-drain.jpg",
    },
  ];
  return (
    <div className=" flex flex-col   gap-6  ">
      {/* Title Section */}

      {/* Content Section */}
      <section className="flex flex-col lg:flex-row gap-4 lg:gap-6 justify-center items-start">
        {/* Left Image */}
        <div className="w-full lg:w-1/4">
          <ImageDescription
            text="Cross-section of a Greens Drainage System."
            url="/Images/existing-green-drainage/cross-section.jpg"
            className="  "
          />
        </div>

        {/* Text Content */}
        <div className="w-full lg:w-2/4 text-left">
          <h2 className="text-xl font-semibold mb-2">
            Existing Green Drainage
          </h2>
          <p className="text-justify sm:text-left">
            A Slit Drainage system in an old &quot;push-up&quot; green can
            literally save it. This system is a network of trenches, using small
            diameter perforated pipes and sand to drain away excess water from
            surface and sub-surface. Projects are surveyed, carefully designed
            and installed using an automatic laser controlled slit trencher. We
            can install a Slit Drainage system for an average sized green in two
            days and the green is back in play immediately, with only the sod
            cut lines visible. We take much pride in workmanship when installing
            a system on a green and make special efforts to ensure the
            Greenskeeper and Golfers are satisfied.
          </p>
        </div>

        {/* Right Image */}
        <div className="w-full lg:w-1/4">
          <ImageDescription
            text="Sample schematic drawing: Survey and Design of a Greens Slit Drainage system."
            url="/Images/existing-green-drainage/simple-schematic.jpg"
          />
        </div>
      </section>

      <HeaderDescriptionSection header="" data={ImageData} className="h-52" />
    </div>
  );
};

export default page;
