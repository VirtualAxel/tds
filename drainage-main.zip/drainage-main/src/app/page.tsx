import Image from "next/image";
import Link from "next/link";
import React from "react";

const Page = () => {
  return (
    <div className="relative min-h-screen 2xl:min-h-max  ">
      <div className="max-w-[1400px] bg-white mx-auto flex flex-col-reverse lg:flex-row justify-between items-start gap-12 py-12 ">
        {/* Left Content */}
        <div className="lg:w-2/3 w-full  h-full">
          <h1 className="text-3xl font-bold mb-4">About TDS</h1>
          <p className="leading-relaxed">
            Since 1992, TDS has been a premium turf drainage company, serving
            the golf course and sports field industry. We enjoy a reputation for
            quality workmanship, reliability, and results. We are turf drainage
            specialists and can recommend a system that will best suit your
            needs.
          </p>
          <p className="mt-4">
            A drainage system is an investment that pays back many times over: a
            comprehensive drainage solution will improve turf health and reduce
            maintenance costs. Subsurface drainage takes away excess soil
            moisture and promotes early and stronger grass growth.
          </p>
          <p className="mt-4 font-bold">
            Watch the video of a TDS crew working on a slit drainage project:
          </p>

          <div className="mt-2  ">
            <iframe
              width="100%"
              height="300"
              src="https://www.youtube.com/embed/3VtOYduzrDA?si=OYl0qmhZ_sfmme1z"
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              className="rounded-md"
            ></iframe>
             
            <p className="mt-4 text-gray-700 font-bold">
              Properly installed, a drain will work 24 hours a day, seven days a
              week, and is virtually maintenance-free. A drainage system is
              truly an investment that will repay you many times over.
            </p>
            
          </div>
        </div>

        <Link href="/sport-sandcapping" className="block  lg:w-1/3">
          <div className=" flex justify-end w-full  ">
            <Image
              src="/sandcapping.gif"
              alt="TDS Project"
              width={500}
              height={500}
              className="  lg:w-80 lg:h-72 shadow-lg rounded-lg"
            />
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Page;
