import type { NextConfig } from "next";

const nextConfig: NextConfig = {
   images:{
    remotePatterns:[
      {
        hostname:"tdsdrainage.com", 
      }
    ]
   }
};

export default nextConfig;
