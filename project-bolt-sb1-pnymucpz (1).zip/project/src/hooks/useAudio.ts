import { useRef, useState, useEffect, useCallback } from 'react';
import { validateAudioUrl } from '../utils/audioUtils';

export function useAudio(url: string | null) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const initializeAudio = useCallback(async (url: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const isValid = await validateAudioUrl(url);
      if (!isValid) {
        throw new Error('Invalid audio source');
      }

      const audio = new Audio();
      
      // Set up error handling
      audio.onerror = (e) => {
        console.error('Audio error:', e);
        setError('Failed to load audio');
        setIsLoading(false);
      };

      // Set up success handling
      audio.oncanplaythrough = () => {
        setIsLoading(false);
        setError(null);
      };

      audio.src = url;
      audioRef.current = audio;

      audio.addEventListener('loadedmetadata', () => {
        setDuration(audio.duration);
      });

      audio.addEventListener('timeupdate', () => {
        setCurrentTime(audio.currentTime);
      });

      audio.addEventListener('ended', () => {
        setIsPlaying(false);
        setCurrentTime(0);
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load audio');
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!url) {
      setError(null);
      setIsLoading(false);
      return;
    }

    initializeAudio(url);

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
    };
  }, [url, initializeAudio]);

  const togglePlay = async () => {
    if (!audioRef.current || error) return;

    try {
      if (isPlaying) {
        await audioRef.current.pause();
      } else {
        await audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    } catch (err) {
      setError('Failed to play audio');
    }
  };

  const setVolume = (value: number) => {
    if (!audioRef.current) return;
    audioRef.current.volume = value;
  };

  return {
    isPlaying,
    duration,
    currentTime,
    togglePlay,
    setVolume,
    error,
    isLoading,
  };
}