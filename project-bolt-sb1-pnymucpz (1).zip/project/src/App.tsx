import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Routes, Route } from 'react-router-dom';
import { Navbar } from './components/navigation/Navbar';
import { SoundPlayer } from './components/SoundPlayer';
import { FooterSection } from './components/footer/FooterSection';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/auth/LoginPage';
import { SignupPage } from './pages/auth/SignupPage';
import { UploadPage } from './pages/upload/UploadPage';
import { SoundPage } from './pages/SoundPage';
import { FAQPage } from './pages/support/FAQPage';
import { ContactPage } from './pages/support/ContactPage';
import { TermsPage } from './pages/support/TermsPage';
import { PrivacyPage } from './pages/support/PrivacyPage';
import { AdminDashboard } from './pages/admin/AdminDashboard';

function App() {
  return (
    <HelmetProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-gray-50 flex flex-col">
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/upload" element={<UploadPage />} />
            <Route path="/sound/:id" element={<SoundPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
          <SoundPlayer />
          <FooterSection />
        </div>
      </BrowserRouter>
    </HelmetProvider>
  );
}

export default App;