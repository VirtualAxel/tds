import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Share2, Download, Heart } from 'lucide-react';
import { SEO } from '../components/SEO';
import { useSoundStore } from '../store/soundStore';
import { AudioVisualizer } from '../components/audio/AudioVisualizer';
import { useAudio } from '../hooks/useAudio';
import { CategoryIcon } from '../components/icons/CategoryIcon';

export function SoundPage() {
  const { id } = useParams();
  const { sounds, favorites, toggleFavorite } = useSoundStore();
  const sound = sounds.find(s => s.id === id);

  const {
    isPlaying,
    duration,
    currentTime,
    togglePlay,
    error,
    isLoading
  } = useAudio(sound?.url || null);

  if (!sound) {
    return (
      <>
        <SEO 
          title="Sound Not Found"
          description="The requested sound could not be found."
        />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Sound not found</h1>
            <Link to="/" className="text-blue-500 hover:underline">
              Return to home
            </Link>
          </div>
        </div>
      </>
    );
  }

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = sound.url;
    link.download = `${sound.title}.mp3`;
    link.click();
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: sound.title,
        text: `Check out this sound on InstantSoundboard!`,
        url: window.location.href,
      });
    } catch (err) {
      // Fallback to copying URL
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <>
      <SEO
        title={sound.title}
        description={`Listen to ${sound.title} sound effect on InstantSoundboard. Category: ${sound.category}. Tags: ${sound.tags.join(', ')}`}
        keywords={[sound.title, sound.category, ...sound.tags]}
        type="music.song"
      />
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Link
            to="/"
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-8"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to sounds
          </Link>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">{sound.title}</h1>
                <div className="flex items-center gap-4 text-gray-600">
                  <span className="flex items-center gap-1">
                    <CategoryIcon category={sound.category} size={16} />
                    {sound.category}
                  </span>
                  <span>•</span>
                  <span>{new Date(sound.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleShare}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Share"
                >
                  <Share2 size={20} />
                </button>
                <button
                  onClick={handleDownload}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Download"
                >
                  <Download size={20} />
                </button>
                <button
                  onClick={() => toggleFavorite(sound.id)}
                  className={`p-2 rounded-full ${
                    favorites.includes(sound.id)
                      ? 'text-red-500 hover:bg-red-50'
                      : 'hover:bg-gray-100'
                  }`}
                  title="Favorite"
                >
                  <Heart
                    size={20}
                    fill={favorites.includes(sound.id) ? 'currentColor' : 'none'}
                  />
                </button>
              </div>
            </div>

            <div className="mb-6">
              <div className="bg-gray-100 rounded-lg p-6">
                <button
                  onClick={togglePlay}
                  disabled={!!error || isLoading}
                  className="w-full h-48 flex items-center justify-center text-4xl hover:scale-105 transition-transform"
                >
                  {isPlaying ? '⏸️' : '▶️'}
                </button>
                <AudioVisualizer
                  isPlaying={isPlaying}
                  currentTime={currentTime}
                  duration={duration}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {sound.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600"
                >
                  #{tag}
                </span>
              ))}
            </div>

            <div className="border-t pt-6">
              <h2 className="text-lg font-semibold mb-4">Keyboard Shortcut</h2>
              {sound.shortcut ? (
                <kbd className="px-3 py-2 bg-gray-100 rounded text-sm">
                  {sound.shortcut}
                </kbd>
              ) : (
                <p className="text-gray-600">No shortcut assigned</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}