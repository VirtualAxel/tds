import React from 'react';
import { BarChart3, Users, Music, AlertCircle } from 'lucide-react';
import { SoundApprovalQueue } from '../../components/admin/SoundApprovalQueue';
import { useUserStore } from '../../store/userStore';
import { useSoundStore } from '../../store/soundStore';
import { Navigate } from 'react-router-dom';

export function AdminDashboard() {
  const { currentUser } = useUserStore();
  const { sounds } = useSoundStore();

  // Redirect if not admin
  if (!currentUser || currentUser.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  const stats = {
    totalSounds: sounds.length,
    pendingApprovals: sounds.filter(s => s.status === 'pending').length,
    totalUsers: 150, // Mock data
    reportedContent: 5, // Mock data
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold mb-8">Admin Dashboard</h1>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Total Sounds"
            value={stats.totalSounds}
            icon={Music}
            color="text-blue-600"
          />
          <StatCard
            title="Pending Approvals"
            value={stats.pendingApprovals}
            icon={AlertCircle}
            color="text-yellow-600"
          />
          <StatCard
            title="Total Users"
            value={stats.totalUsers}
            icon={Users}
            color="text-green-600"
          />
          <StatCard
            title="Reported Content"
            value={stats.reportedContent}
            icon={BarChart3}
            color="text-red-600"
          />
        </div>

        {/* Sound Approval Queue */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Sound Approval Queue</h2>
          <SoundApprovalQueue />
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ElementType;
  color: string;
}

function StatCard({ title, value, icon: Icon, color }: StatCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
        <Icon className={`h-8 w-8 ${color}`} />
      </div>
    </div>
  );
}