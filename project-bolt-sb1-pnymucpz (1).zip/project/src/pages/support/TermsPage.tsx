import React from 'react';
import { ScrollText } from 'lucide-react';

export function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-12">
          <ScrollText className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold mb-4">Terms of Use</h1>
          <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-8 space-y-8">
          <section>
            <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-600">
              By accessing and using InstantSoundboard, you accept and agree to be bound by the terms
              and provision of this agreement.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">2. User Content</h2>
            <p className="text-gray-600">
              Users are responsible for the content they upload. Content must not violate copyright
              laws or contain inappropriate material. We reserve the right to remove content that
              violates these terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">3. Copyright Policy</h2>
            <p className="text-gray-600">
              Users may only upload content they own or have permission to use. Any copyright
              infringement will result in content removal and possible account termination.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">4. Account Security</h2>
            <p className="text-gray-600">
              Users are responsible for maintaining the security of their accounts and passwords.
              InstantSoundboard cannot and will not be liable for any loss or damage from failure
              to comply with this security obligation.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">5. Privacy</h2>
            <p className="text-gray-600">
              Your privacy is important to us. Please refer to our Privacy Policy for information
              about how we collect, use, and disclose information about you.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}