import React from 'react';
import { Link } from 'react-router-dom';
import { HelpCircle } from 'lucide-react';

export function FAQPage() {
  const faqs = [
    {
      question: "How do I upload a sound?",
      answer: "Click the 'Upload' button in the navigation bar. You can upload MP3, WAV, or OGG files up to 10MB in size. Add a title, category, and tags to help others find your sound."
    },
    {
      question: "What sound formats are supported?",
      answer: "We support MP3, WAV, and OGG audio formats. Files must be under 10MB in size for optimal performance."
    },
    {
      question: "Can I download sounds?",
      answer: "Yes! Each sound has a download button. Click it to save the sound to your device."
    },
    {
      question: "How do I create a soundboard?",
      answer: "Add sounds to your favorites by clicking the heart icon. Your favorites automatically become your personal soundboard."
    },
    {
      question: "Are there keyboard shortcuts?",
      answer: "Yes! You can assign keyboard shortcuts to your favorite sounds for quick access."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-12">
          <HelpCircle className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-gray-600">Find answers to common questions about InstantSoundboard</p>
        </div>

        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
              <p className="text-gray-600">{faq.answer}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <Link
            to="/contact"
            className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            Contact Support
          </Link>
        </div>
      </div>
    </div>
  );
}