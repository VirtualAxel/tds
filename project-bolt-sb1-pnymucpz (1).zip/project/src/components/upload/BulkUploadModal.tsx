import React, { useState, useCallback } from 'react';
import { Upload, X, AlertCircle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { useSoundStore } from '../../store/soundStore';
import { validateAudioFile } from '../../utils/audioUtils';

interface BulkUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BulkUploadModal({ isOpen, onClose }: BulkUploadModalProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { uploadSound } = useSoundStore();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setError(null);
    const validFiles: File[] = [];

    for (const file of acceptedFiles) {
      try {
        await validateAudioFile(file);
        validFiles.push(file);
      } catch (err) {
        console.error(`Invalid file ${file.name}:`, err);
      }
    }

    setFiles(prev => [...prev, ...validFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'audio/*': ['.mp3', '.wav', '.ogg']
    },
    multiple: true
  });

  const handleUpload = async () => {
    setIsUploading(true);
    setError(null);

    try {
      await Promise.all(files.map(file => 
        uploadSound(file, {
          title: file.name.replace(/\.[^/.]+$/, ''),
          category: 'uncategorized',
          tags: [],
          status: 'approved' // Admins can directly approve
        })
      ));
      onClose();
    } catch (err) {
      setError('Failed to upload some files');
    } finally {
      setIsUploading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Bulk Upload Sounds</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X size={20} />
          </button>
        </div>

        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center mb-4 ${
            isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600">
            {isDragActive
              ? 'Drop the files here...'
              : 'Drag & drop audio files here, or click to select files'}
          </p>
        </div>

        {files.length > 0 && (
          <div className="mb-4">
            <h3 className="font-medium mb-2">Selected Files ({files.length})</h3>
            <div className="max-h-48 overflow-y-auto">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded mb-2"
                >
                  <span className="text-sm truncate">{file.name}</span>
                  <button
                    onClick={() => setFiles(files.filter((_, i) => i !== index))}
                    className="text-gray-500 hover:text-red-500"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-md mb-4">
            <AlertCircle size={16} />
            <span className="text-sm">{error}</span>
          </div>
        )}

        <button
          onClick={handleUpload}
          disabled={files.length === 0 || isUploading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isUploading ? 'Uploading...' : `Upload ${files.length} Files`}
        </button>
      </div>
    </div>
  );
}