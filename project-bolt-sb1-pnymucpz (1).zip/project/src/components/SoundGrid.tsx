import React from 'react';
import { useSoundStore } from '../store/soundStore';
import { SoundButton } from './SoundButton';

export function SoundGrid() {
  const { sounds, favorites, toggleFavorite, setCurrentSound } = useSoundStore();

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6 md:gap-8">
      {sounds.map((sound) => (
        <SoundButton
          key={sound.id}
          sound={sound}
          onPlay={() => setCurrentSound(sound)}
          onToggleFavorite={() => toggleFavorite(sound.id)}
          isFavorite={favorites.includes(sound.id)}
        />
      ))}
    </div>
  );
}