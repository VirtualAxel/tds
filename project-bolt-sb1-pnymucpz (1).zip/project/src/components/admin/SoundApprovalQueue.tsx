import React from 'react';
import { Check, X } from 'lucide-react';
import { useSoundStore } from '../../store/soundStore';
import { Sound } from '../../types/sound';

export function SoundApprovalQueue() {
  const { sounds, approveSound, rejectSound } = useSoundStore();
  const pendingSounds = sounds.filter(sound => sound.status === 'pending');

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Pending Approvals</h2>
      
      {pendingSounds.length === 0 ? (
        <p className="text-gray-500">No sounds pending approval</p>
      ) : (
        <div className="space-y-4">
          {pendingSounds.map((sound) => (
            <SoundApprovalItem
              key={sound.id}
              sound={sound}
              onApprove={() => approveSound(sound.id)}
              onReject={() => rejectSound(sound.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface SoundApprovalItemProps {
  sound: Sound;
  onApprove: () => Promise<void>;
  onReject: () => Promise<void>;
}

function SoundApprovalItem({ sound, onApprove, onReject }: SoundApprovalItemProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleAction = async (action: () => Promise<void>) => {
    setIsProcessing(true);
    try {
      await action();
    } catch (error) {
      console.error('Failed to process sound:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
      <div>
        <h3 className="font-medium">{sound.title}</h3>
        <p className="text-sm text-gray-500">
          Category: {sound.category} • Tags: {sound.tags.join(', ')}
        </p>
      </div>
      
      <div className="flex gap-2">
        <button
          onClick={() => handleAction(onApprove)}
          disabled={isProcessing}
          className="p-2 text-green-600 hover:bg-green-50 rounded-full disabled:opacity-50"
        >
          <Check size={20} />
        </button>
        <button
          onClick={() => handleAction(onReject)}
          disabled={isProcessing}
          className="p-2 text-red-600 hover:bg-red-50 rounded-full disabled:opacity-50"
        >
          <X size={20} />
        </button>
      </div>
    </div>
  );
}