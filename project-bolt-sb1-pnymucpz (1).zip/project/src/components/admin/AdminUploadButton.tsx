import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { BulkUploadModal } from '../upload/BulkUploadModal';
import { SingleUploadModal } from '../upload/SingleUploadModal';

export function AdminUploadButton() {
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [showSingleUpload, setShowSingleUpload] = useState(false);

  return (
    <>
      <div className="relative inline-block">
        <button
          onClick={() => setShowBulkUpload(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          <Upload size={16} />
          <span>Bulk Upload</span>
        </button>
      </div>

      <BulkUploadModal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
      />
      
      <SingleUploadModal
        isOpen={showSingleUpload}
        onClose={() => setShowSingleUpload(false)}
      />
    </>
  );
}