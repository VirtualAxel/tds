import React from 'react';
import { Music, Mic, Zap, Laugh } from 'lucide-react';

interface CategoryIconProps {
  category: string;
  size?: number;
}

export function CategoryIcon({ category, size = 24 }: CategoryIconProps) {
  switch (category.toLowerCase()) {
    case 'music':
      return <Music size={size} />;
    case 'voice':
      return <Mic size={size} />;
    case 'effect':
      return <Zap size={size} />;
    case 'meme':
      return <Laugh size={size} />;
    default:
      return <Music size={size} />;
  }
}