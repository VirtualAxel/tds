import React from 'react';
import { Play, Pause, Volume2, Download } from 'lucide-react';
import { useAudio } from '../hooks/useAudio';
import { AudioVisualizer } from './audio/AudioVisualizer';
import { AudioError } from './audio/AudioError';
import { AudioLoading } from './audio/AudioLoading';
import { useSoundStore } from '../store/soundStore';

export function SoundPlayer() {
  const { currentSound, volume, setVolume } = useSoundStore();
  const {
    isPlaying,
    duration,
    currentTime,
    togglePlay,
    setVolume: setAudioVolume,
    error,
    isLoading,
  } = useAudio(currentSound?.url || null);

  React.useEffect(() => {
    setAudioVolume(volume);
  }, [volume, setAudioVolume]);

  if (!currentSound) return null;

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
  };

  const handleDownload = () => {
    if (!currentSound?.url) return;
    const link = document.createElement('a');
    link.href = currentSound.url;
    link.download = `${currentSound.title}.mp3`;
    link.click();
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 sm:p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4">
          <button
            onClick={togglePlay}
            disabled={!!error || isLoading}
            className="p-2 rounded-full bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isPlaying ? <Pause size={24} /> : <Play size={24} />}
          </button>
          
          <div className="flex-1 w-full">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-900 truncate">{currentSound.title}</h3>
              <div className="flex items-center">
                {error && <AudioError message={error} />}
                {isLoading && <AudioLoading />}
              </div>
            </div>
            {!error && (
              <AudioVisualizer
                isPlaying={isPlaying}
                currentTime={currentTime}
                duration={duration}
              />
            )}
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <div className="hidden sm:flex items-center gap-2">
              <Volume2 size={20} className="text-gray-500" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolumeChange}
                className="w-20 sm:w-24"
              />
            </div>
            
            <button
              onClick={handleDownload}
              disabled={!!error || isLoading}
              className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Download"
            >
              <Download size={20} className="text-gray-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}