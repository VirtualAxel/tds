import React, { useRef, useEffect } from 'react';

interface AudioVisualizerProps {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
}

export function AudioVisualizer({ isPlaying, currentTime, duration }: AudioVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const barWidth = 3;
    const barGap = 2;
    const barCount = Math.floor(width / (barWidth + barGap));

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      
      // Create a gradient effect
      const gradient = ctx.createLinearGradient(0, 0, width, 0);
      gradient.addColorStop(0, '#4F46E5');
      gradient.addColorStop(1, '#818CF8');
      
      ctx.fillStyle = gradient;

      // Draw animated bars
      for (let i = 0; i < barCount; i++) {
        const x = i * (barWidth + barGap);
        // Create a semi-random height based on position and time
        const heightMultiplier = Math.sin((i + currentTime * 5) / 10) * 0.5 + 0.5;
        const barHeight = height * heightMultiplier;
        
        ctx.fillRect(x, (height - barHeight) / 2, barWidth, barHeight);
      }

      if (isPlaying) {
        requestAnimationFrame(render);
      }
    };

    render();
  }, [isPlaying, currentTime]);

  return (
    <canvas
      ref={canvasRef}
      width={400}
      height={60}
      className="w-full h-[60px]"
    />
  );
}