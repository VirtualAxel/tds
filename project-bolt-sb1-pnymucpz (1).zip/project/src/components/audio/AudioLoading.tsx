import React from 'react';
import { Loader2 } from 'lucide-react';

export function AudioLoading() {
  return (
    <div className="flex items-center gap-2 text-gray-600">
      <Loader2 size={16} className="animate-spin" />
      <span className="text-sm">Loading audio...</span>
    </div>
  );
}