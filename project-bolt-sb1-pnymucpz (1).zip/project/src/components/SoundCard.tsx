import React from 'react';
import { Heart } from 'lucide-react';

interface SoundCardProps {
  id: string;
  title: string;
  tags: string[];
  shortcut?: string;
  isFavorite: boolean;
  onPlay: () => void;
  onToggleFavorite: () => void;
}

export function SoundCard({
  id,
  title,
  tags,
  shortcut,
  isFavorite,
  onPlay,
  onToggleFavorite,
}: SoundCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-medium text-lg">{title}</h3>
        <button
          onClick={onToggleFavorite}
          className={`p-2 rounded-full ${
            isFavorite
              ? 'text-red-500 hover:text-red-600'
              : 'text-gray-400 hover:text-gray-500'
          }`}
        >
          <Heart
            size={20}
            fill={isFavorite ? 'currentColor' : 'none'}
          />
        </button>
      </div>

      <div className="flex flex-wrap gap-2 mb-3">
        {tags.map((tag) => (
          <span
            key={tag}
            className="px-2 py-1 text-sm bg-gray-100 rounded-full text-gray-600"
          >
            {tag}
          </span>
        ))}
      </div>

      <button
        onClick={onPlay}
        className="w-full py-2 px-4 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
      >
        Play {shortcut && `(${shortcut})`}
      </button>
    </div>
  );
}