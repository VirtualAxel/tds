import React, { useState } from 'react';
import { Heart, Share2, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Sound } from '../types/sound';
import { CategoryIcon } from './icons/CategoryIcon';

interface SoundButtonProps {
  sound: Sound;
  onPlay: () => void;
  onToggleFavorite: () => void;
  isFavorite: boolean;
}

export function SoundButton({ sound, onPlay, onToggleFavorite, isFavorite }: SoundButtonProps) {
  const [isPressed, setIsPressed] = useState(false);

  const getButtonColor = () => {
    const colors = {
      meme: 'bg-green-500 hover:bg-green-600',
      effect: 'bg-red-500 hover:bg-red-600',
      music: 'bg-blue-500 hover:bg-blue-600',
      voice: 'bg-purple-500 hover:bg-purple-600',
    };
    return colors[sound.category as keyof typeof colors] || 'bg-gray-500 hover:bg-gray-600';
  };

  const handleButtonPress = () => {
    setIsPressed(true);
    onPlay();
    
    // Reset the pressed state after animation completes
    setTimeout(() => {
      setIsPressed(false);
    }, 200);
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <button
        onClick={handleButtonPress}
        className={`w-24 h-24 rounded-full shadow-lg ${getButtonColor()} 
          transition-all duration-200 transform 
          ${isPressed ? 'scale-90 shadow-inner translate-y-1' : 'hover:scale-105'} 
          focus:outline-none focus:ring-4 focus:ring-opacity-50 focus:ring-blue-300 
          flex items-center justify-center text-white relative`}
        style={{
          boxShadow: isPressed ? 'inset 0 4px 6px rgba(0, 0, 0, 0.3)' : '0 4px 6px rgba(0, 0, 0, 0.2), 0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        <CategoryIcon category={sound.category} />
        <span className="sr-only">Play {sound.title}</span>
        
        {/* Button highlight effect */}
        <div className={`absolute inset-0 rounded-full bg-white opacity-10 
          ${isPressed ? 'opacity-0' : 'opacity-10'} 
          transition-opacity duration-200`} 
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 50%)',
            pointerEvents: 'none'
          }}
        />
      </button>
      
      <Link to={`/sound/${sound.id}`} className="text-sm font-medium text-center hover:text-blue-600">
        {sound.title}
      </Link>
      
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleFavorite}
          className="p-1 hover:text-red-500"
        >
          <Heart
            size={16}
            fill={isFavorite ? 'currentColor' : 'none'}
            className={isFavorite ? 'text-red-500' : 'text-gray-500'}
          />
        </button>
        <button className="p-1 hover:text-blue-500">
          <Share2 size={16} className="text-gray-500" />
        </button>
        <button className="p-1 hover:text-green-500">
          <Download size={16} className="text-gray-500" />
        </button>
      </div>
    </div>
  );
}