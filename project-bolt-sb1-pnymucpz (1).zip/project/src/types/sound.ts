export interface Sound {
  id: string;
  title: string;
  category: string;
  tags: string[];
  url: string;
  shortcut?: string;
  userId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface SoundState {
  sounds: Sound[];
  favorites: string[];
  currentSound: Sound | null;
  volume: number;
  setVolume: (volume: number) => void;
  toggleFavorite: (id: string) => void;
  setCurrentSound: (sound: Sound | null) => void;
  uploadSound: (file: File, metadata: Partial<Sound>) => Promise<void>;
  approveSound: (id: string) => Promise<void>;
  rejectSound: (id: string) => Promise<void>;
}