import { create } from 'zustand';
import { User, UserState } from '../types/user';

export const useUserStore = create<UserState>((set) => ({
  currentUser: null,
  isAuthenticated: false,
  
  login: async (email: string, password: string) => {
    // TODO: Replace with Supabase authentication
    const mockUser: User = {
      id: '1',
      username: email.split('@')[0],
      email,
      role: 'user',
      createdAt: new Date().toISOString()
    };
    set({ currentUser: mockUser, isAuthenticated: true });
  },

  signup: async (email: string, password: string, username: string) => {
    // TODO: Replace with Supabase authentication
    const mockUser: User = {
      id: Date.now().toString(),
      username,
      email,
      role: 'user',
      createdAt: new Date().toISOString()
    };
    set({ currentUser: mockUser, isAuthenticated: true });
  },
  
  logout: () => set({ currentUser: null, isAuthenticated: false })
}));