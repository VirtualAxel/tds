import { create } from 'zustand';
import { Sound, SoundState } from '../types/sound';
import { uploadAudioFile } from '../utils/audioUtils';
import { demoSounds } from '../data/demoSounds';

interface State extends SoundState {
  sounds: Sound[];
  favorites: string[];
  currentSound: Sound | null;
  volume: number;
}

interface Actions {
  setVolume: (volume: number) => void;
  toggleFavorite: (id: string) => void;
  setCurrentSound: (sound: Sound | null) => void;
  uploadSound: (file: File, metadata: Partial<Sound>) => Promise<void>;
  approveSound: (id: string) => Promise<void>;
  rejectSound: (id: string) => Promise<void>;
}

export const useSoundStore = create<State & Actions>((set) => ({
  sounds: demoSounds,
  favorites: [],
  currentSound: null,
  volume: 0.5,

  setVolume: (volume) => set({ volume }),
  
  toggleFavorite: (id) => 
    set((state) => ({
      favorites: state.favorites.includes(id)
        ? state.favorites.filter((fid) => fid !== id)
        : [...state.favorites, id],
    })),
  
  setCurrentSound: (sound) => set({ currentSound: sound }),
  
  uploadSound: async (file, metadata) => {
    try {
      const url = await uploadAudioFile(file);
      const newSound: Sound = {
        id: Date.now().toString(),
        title: metadata.title || file.name,
        category: metadata.category || 'Uncategorized',
        tags: metadata.tags || [],
        url,
        userId: metadata.userId || '',
        status: metadata.status || 'pending',
        createdAt: new Date().toISOString(),
      };
      
      set((state) => ({
        sounds: [...state.sounds, newSound],
      }));
    } catch (error) {
      throw new Error('Failed to upload sound');
    }
  },
  
  approveSound: async (id) => {
    set((state) => ({
      sounds: state.sounds.map((sound) =>
        sound.id === id ? { ...sound, status: 'approved' } : sound
      ),
    }));
  },
  
  rejectSound: async (id) => {
    set((state) => ({
      sounds: state.sounds.map((sound) =>
        sound.id === id ? { ...sound, status: 'rejected' } : sound
      ),
    }));
  },
}));