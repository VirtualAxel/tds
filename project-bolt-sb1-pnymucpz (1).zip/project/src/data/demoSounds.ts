import { Sound } from '../types/sound';

export const demoSounds: Sound[] = [
  {
    id: '1',
    title: 'Vine Boom',
    category: 'meme',
    tags: ['meme', 'vine', 'effect'],
    url: 'https://www.myinstants.com/media/sounds/vine-boom.mp3',
    userId: 'demo',
    status: 'approved',
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'Bruh',
    category: 'meme',
    tags: ['meme', 'reaction'],
    url: 'https://www.myinstants.com/media/sounds/movie_1.mp3',
    userId: 'demo',
    status: 'approved',
    createdAt: new Date().toISOString(),
  },
  {
    id: '3',
    title: 'Emotional Damage',
    category: 'voice',
    tags: ['funny', 'voice', 'meme'],
    url: 'https://www.myinstants.com/media/sounds/emotional-damage-meme.mp3',
    userId: 'demo',
    status: 'approved',
    createdAt: new Date().toISOString(),
  },
  {
    id: '4',
    title: 'Rick Roll',
    category: 'music',
    tags: ['music', 'meme', 'classic'],
    url: 'https://www.myinstants.com/media/sounds/y2mate_3wYRp2.mp3',
    userId: 'demo',
    status: 'approved',
    createdAt: new Date().toISOString(),
  },
  {
    id: '5',
    title: 'Windows Error',
    category: 'effect',
    tags: ['effect', 'windows', 'error'],
    url: 'https://www.myinstants.com/media/sounds/windows-error.mp3',
    userId: 'demo',
    status: 'approved',
    createdAt: new Date().toISOString(),
  }
];